﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            User user = new User("admin", "admin");
            user.DataChanged += (object sender, EventArgs e) => Console.WriteLine($"Изменены данные пользователя со следующим логином: {((User)sender).Login}");

            Console.WriteLine("Введите логин");
            user.Login = Console.ReadLine();

            Console.WriteLine("Введите пароль");
            user.Password = Console.ReadLine();
        }
    }
}
