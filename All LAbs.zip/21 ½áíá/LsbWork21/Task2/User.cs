﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    internal class User
    {
        private string login;
        private string password;

        public string Login
        {
            get => login;
            set
            {
                login = value;
                DataChanged?.Invoke(this, EventArgs.Empty);
            }

        }
        public string Password
        {
            get => password;
            set
            {
                password = value;
                DataChanged?.Invoke(this, EventArgs.Empty);
            }
        }
        public User(string login, string password) { }

        public event EventHandler DataChanged;
    }
}
