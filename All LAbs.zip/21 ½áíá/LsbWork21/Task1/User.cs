﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    internal class User
    {
        private string login;
        private string password;

        public string Login
        {
            get => login;
            set
            {
                if (String.IsNullOrWhiteSpace(value))
                {
                    DataChanged?.Invoke("Невозможно изменить логин на пустую строку");

                }
                else
                {
                    login = value;
                    DataChanged?.Invoke($"Логин изменился на: {value}");
                }
            }

        }
        public string Password
        {
            get => password;
            set
            {
                if (value.Length < 6 || value.Length > 20)
                {
                    DataChanged?.Invoke("Длина пароля должна быть от 6 до 20 символов");

                }
                else
                {
                    password = value;
                    DataChanged?.Invoke($"Пароль изменился на: {value}");
                }
            }
        }

        public User(string login, string password) { }

        public delegate void UserHandler(string messege);
        public event UserHandler DataChanged;

    }
}
