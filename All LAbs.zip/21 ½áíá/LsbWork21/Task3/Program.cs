﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            User user = new User("admin", "admin");
            user.DataChanged += (object sender, DataEventArgs e) => Console.WriteLine($"{e?.DateTime}: у пользователя {((User)sender).Login} изменено {e?.Parameter}");

            Console.WriteLine("Введите логин");
            user.Login = Console.ReadLine();

            Console.WriteLine("Введите пароль");
            user.Password = Console.ReadLine();
        }
    }
}
