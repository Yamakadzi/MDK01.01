﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task3
{
    internal class User
    {
        private string login;
        private string password;

        public string Login
        {
            get => login;
            set
            {
                login = value;
                DataChanged?.Invoke(this, new DataEventArgs() { Parameter = "Логин", DateTime = DateTime.Now });
            }

        }
        public string Password
        {
            get => password;
            set
            {
                password = value;
                DataChanged?.Invoke(this, new DataEventArgs() { Parameter = "Пароль", DateTime = DateTime.Now });
            }
        }
        public User(string login, string password) { }

        public event EventHandler<DataEventArgs> DataChanged;
    }
}
