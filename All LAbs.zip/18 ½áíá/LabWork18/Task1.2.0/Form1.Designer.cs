﻿namespace Task1._2._0
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Rows_textBox = new System.Windows.Forms.TextBox();
            this.Page_textBox = new System.Windows.Forms.TextBox();
            this.firstPage_Button = new System.Windows.Forms.Button();
            this.nextPage_Button = new System.Windows.Forms.Button();
            this.lastPage_Button = new System.Windows.Forms.Button();
            this.prevPage_Button = new System.Windows.Forms.Button();
            this.currentPage_Label = new System.Windows.Forms.Label();
            this.extraPage_Button = new System.Windows.Forms.Button();
            this.rowsInfo_label = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(788, 306);
            this.dataGridView1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 339);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Количество строк";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(0, 409);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Введите страницу";
            // 
            // Rows_textBox
            // 
            this.Rows_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Rows_textBox.Location = new System.Drawing.Point(0, 363);
            this.Rows_textBox.Name = "Rows_textBox";
            this.Rows_textBox.Size = new System.Drawing.Size(51, 23);
            this.Rows_textBox.TabIndex = 3;
            this.Rows_textBox.TextChanged += new System.EventHandler(this.Rows_textBox_TextChanged);
            // 
            // Page_textBox
            // 
            this.Page_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Page_textBox.Location = new System.Drawing.Point(0, 439);
            this.Page_textBox.Name = "Page_textBox";
            this.Page_textBox.Size = new System.Drawing.Size(51, 23);
            this.Page_textBox.TabIndex = 4;
            this.Page_textBox.TextChanged += new System.EventHandler(this.Page_textBox_TextChanged);
            // 
            // firstPage_Button
            // 
            this.firstPage_Button.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.firstPage_Button.Location = new System.Drawing.Point(504, 565);
            this.firstPage_Button.Name = "firstPage_Button";
            this.firstPage_Button.Size = new System.Drawing.Size(75, 23);
            this.firstPage_Button.TabIndex = 5;
            this.firstPage_Button.Text = "<<";
            this.firstPage_Button.UseVisualStyleBackColor = true;
            this.firstPage_Button.Click += new System.EventHandler(this.firstPage_Click);
            // 
            // nextPage_Button
            // 
            this.nextPage_Button.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.nextPage_Button.Location = new System.Drawing.Point(423, 485);
            this.nextPage_Button.Name = "nextPage_Button";
            this.nextPage_Button.Size = new System.Drawing.Size(75, 23);
            this.nextPage_Button.TabIndex = 7;
            this.nextPage_Button.Text = ">";
            this.nextPage_Button.UseVisualStyleBackColor = true;
            this.nextPage_Button.Click += new System.EventHandler(this.nextPage_Click);
            // 
            // lastPage_Button
            // 
            this.lastPage_Button.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.lastPage_Button.Location = new System.Drawing.Point(504, 485);
            this.lastPage_Button.Name = "lastPage_Button";
            this.lastPage_Button.Size = new System.Drawing.Size(75, 23);
            this.lastPage_Button.TabIndex = 8;
            this.lastPage_Button.Text = ">>";
            this.lastPage_Button.UseVisualStyleBackColor = true;
            this.lastPage_Button.Click += new System.EventHandler(this.lastPage_Click);
            // 
            // prevPage_Button
            // 
            this.prevPage_Button.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.prevPage_Button.Location = new System.Drawing.Point(276, 485);
            this.prevPage_Button.Name = "prevPage_Button";
            this.prevPage_Button.Size = new System.Drawing.Size(75, 23);
            this.prevPage_Button.TabIndex = 9;
            this.prevPage_Button.Text = "<";
            this.prevPage_Button.UseVisualStyleBackColor = true;
            this.prevPage_Button.Click += new System.EventHandler(this.prevPage_Click);
            // 
            // currentPage_Label
            // 
            this.currentPage_Label.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.currentPage_Label.AutoSize = true;
            this.currentPage_Label.Location = new System.Drawing.Point(357, 489);
            this.currentPage_Label.Name = "currentPage_Label";
            this.currentPage_Label.Size = new System.Drawing.Size(60, 15);
            this.currentPage_Label.TabIndex = 10;
            this.currentPage_Label.Text = "Страница";
            this.currentPage_Label.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // extraPage_Button
            // 
            this.extraPage_Button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.extraPage_Button.Location = new System.Drawing.Point(778, 451);
            this.extraPage_Button.Name = "extraPage_Button";
            this.extraPage_Button.Size = new System.Drawing.Size(115, 23);
            this.extraPage_Button.TabIndex = 11;
            this.extraPage_Button.Text = "Показать ещё";
            this.extraPage_Button.UseVisualStyleBackColor = true;
            this.extraPage_Button.Click += new System.EventHandler(this.extraPage_Button_Click);
            // 
            // rowsInfo_label
            // 
            this.rowsInfo_label.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rowsInfo_label.AutoSize = true;
            this.rowsInfo_label.Location = new System.Drawing.Point(778, 489);
            this.rowsInfo_label.Name = "rowsInfo_label";
            this.rowsInfo_label.Size = new System.Drawing.Size(38, 15);
            this.rowsInfo_label.TabIndex = 12;
            this.rowsInfo_label.Text = "label3";
            this.rowsInfo_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 528);
            this.Controls.Add(this.rowsInfo_label);
            this.Controls.Add(this.extraPage_Button);
            this.Controls.Add(this.currentPage_Label);
            this.Controls.Add(this.prevPage_Button);
            this.Controls.Add(this.lastPage_Button);
            this.Controls.Add(this.nextPage_Button);
            this.Controls.Add(this.firstPage_Button);
            this.Controls.Add(this.Page_textBox);
            this.Controls.Add(this.Rows_textBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView dataGridView1;
        private Label label1;
        private Label label2;
        private TextBox Rows_textBox;
        private TextBox Page_textBox;
        private Button firstPage_Button;
        private Button nextPage_Button;
        private Button lastPage_Button;
        private Button prevPage_Button;
        private Label currentPage_Label;
        private Button extraPage_Button;
        private Label rowsInfo_label;
    }
}