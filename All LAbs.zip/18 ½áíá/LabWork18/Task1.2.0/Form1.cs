namespace Task1._2._0
{
    public partial class Form1 : Form
    {
        DirectoryInfo directory;
        FileInfo[] files;

        public int countOfRows;
        private int currentPage;
        private int extraPage;
        public int CurrentPage
        {
            get => currentPage; set
            {
                currentPage = value;
                currentPage_Label.Text = Convert.ToString(currentPage); 
            }
        }

        public Form1()
        {
            InitializeComponent();
            directory = new DirectoryInfo(@"D:\�����");
            files = directory.GetFiles("*", SearchOption.AllDirectories);
            CurrentPage = 0;
            countOfRows = 5;
            extraPage = 0;
            LoadPage(CurrentPage);

        }

        public void LoadPage(int Page, int extraPage = 0)
        {
            dataGridView1.DataSource = files
                .Select(f => new { f.Name, f.FullName, f.Length, f.CreationTime })
                .Skip(Page * countOfRows)
                .Take(countOfRows + countOfRows*extraPage)
                .OrderBy(f => f.Name)
                .ToList();
                
            if (currentPage <= 0)
            {
                firstPage_Button.Enabled = false;
                prevPage_Button.Enabled = false;
            }
            else 
            {
                firstPage_Button.Enabled = true;
                prevPage_Button.Enabled = true;
            }

            int maxPage = files.Length / (countOfRows);

            if (files.Length % countOfRows == 0) 
            {
                maxPage--;
            }

            if (currentPage >= maxPage)
            {
                nextPage_Button.Enabled = false;
                lastPage_Button.Enabled = false;
            }
            else
            {
                nextPage_Button.Enabled = true;
                lastPage_Button.Enabled = true;
            }

            if (files.Length <= countOfRows * (currentPage + 1) + countOfRows * extraPage)
            {

                extraPage_Button.Enabled = false;
            }
            else 
            {
                extraPage_Button.Enabled = true;
            }
            rowsInfo_label.Text = $"��������: {dataGridView1.Rows.Count } ������� ��: {files.Length} ";
        }

        private void Rows_textBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                countOfRows = Convert.ToInt32(Rows_textBox.Text);
                LoadPage(CurrentPage);
                extraPage = 0;
            }
            catch
            {

            }
        }

        private void Page_textBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                CurrentPage = Convert.ToInt32(Page_textBox.Text);
                LoadPage(CurrentPage);
                extraPage = 0;
            }
            catch
            {

            }
        }

        private void firstPage_Click(object sender, EventArgs e)
        {
            CurrentPage = 0;
            LoadPage(CurrentPage);
            extraPage = 0;
        }

        private void prevPage_Click(object sender, EventArgs e)
        {
            CurrentPage--;
            LoadPage(CurrentPage);
            extraPage = 0;
        }

        private void nextPage_Click(object sender, EventArgs e)
        {
            CurrentPage++;
            LoadPage(CurrentPage);
            extraPage = 0;
        }

        private void lastPage_Click(object sender, EventArgs e)
        {
            int maxPage = files.Length/countOfRows;
            if (files.Length % countOfRows == 0)
            {
                maxPage--;
            }
            CurrentPage = maxPage;
            LoadPage(CurrentPage);
            extraPage = 0;
        }

     

        private void extraPage_Button_Click(object sender, EventArgs e)
        {
            extraPage++;
            LoadPage(CurrentPage, extraPage);
        }
    }
}