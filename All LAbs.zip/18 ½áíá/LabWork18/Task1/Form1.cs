namespace Task1
{
    public partial class Form1 : Form
    {
        DirectoryInfo directory;
        FileInfo[] files;

        public int countOfRows;
        public int currentPage;

        public Form1()
        {
            InitializeComponent();
            directory = new DirectoryInfo(@"D:\�����");
            files = directory.GetFiles("*", SearchOption.AllDirectories);
            currentPage = 1;
            countOfRows = 5;
            LoadPage(currentPage);
        }

        public void LoadPage(int Page) 
        {
            dataGridView1.DataSource = files
                .ToList()
                .Skip(Page * countOfRows)
                .Take(countOfRows)
                .OrderBy(f => f.Name)
                .ToList();
        }

        private void Rows_textBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                countOfRows = Convert.ToInt32(Rows_textBox.Text);
                LoadPage(currentPage);
            }
            catch 
            { 
                
            }
        }

        
    }
}