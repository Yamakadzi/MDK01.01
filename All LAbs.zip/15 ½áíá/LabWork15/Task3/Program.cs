﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
namespace Task3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите строку");
            string stroka = Console.ReadLine();
            Regex regex = new Regex(@"^[a - z\d\-_] + ([a - z\d]+\.) + [a - z]{2,}$", RegexOptions.IgnoreCase);
            Console.WriteLine(regex.IsMatch(stroka) ? "Это email" : "Это не email");
        }
    }
}
