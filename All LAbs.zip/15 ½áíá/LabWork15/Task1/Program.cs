﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Task1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите строку:");
            string stroka = Console.ReadLine();
            Console.WriteLine(Regex.IsMatch(stroka, @"^\+7\(9\d{2}\)\d{3}-\d{2}-\d{2}$") ? "Строка является номером телефона" : "Строка не является номером телефона");
            Console.ReadLine();
        }
    }
}
