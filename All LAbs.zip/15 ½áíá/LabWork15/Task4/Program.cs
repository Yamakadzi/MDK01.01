﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
namespace Task4
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Regex regex = new Regex(@"(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\?\.\!]).{6,}");
            string pasword = string.Empty;
            do
            {
                Console.WriteLine("Введите пароль");
                pasword = Console.ReadLine();
               
            }
            while (!regex.IsMatch(pasword));
            Console.WriteLine("Пароль надёжный");
        }
    }
}
