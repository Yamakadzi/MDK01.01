﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12laba
{
    internal partial class Program
    {
        static void Main(string[] args)
        {
            Worker worker = new Worker("Виноградов Василий Дмитриевич", "Юрист", 75000);
            Worker worker1 = new Worker();
            worker.Print();
            worker1.Print();
        }
    }
}
