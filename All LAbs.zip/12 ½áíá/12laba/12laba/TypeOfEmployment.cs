﻿namespace _12laba
{
    enum TypeOfEmployment
    {
        Fulltime,
        PartTime,
        internship
    }
}
