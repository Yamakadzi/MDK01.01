﻿using System;

namespace _12laba
{

    struct Worker
    {

        private string _name;
        private string _post;
        private double _salary;
        public TypeOfEmployment typeofemployment;
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                if (value.Length > 0)
                {
                    _name = value;
                }
                else
                {
                    Console.WriteLine("Incorrect data");
                }
            }
        }
        public string Post
        {
            get
            {
                return _post;
            }
            set
            {
                if (value.Length > 0)
                {
                    _post = value;
                }
                else
                {
                    Console.WriteLine("Incorrect data");
                }
            }
        }
        public double Salary
        {
            get
            {
                return _salary;
            }
            set
            {
                if (value >= 0)
                {
                    _salary = value;
                }
                else
                {
                    Console.WriteLine("Incorrect data");
                }
            }
        }
        public Worker(string name, string post, double salary) : this()
        {
            _name = name;
            _post = post;
            _salary = salary;
            typeofemployment = TypeOfEmployment.Fulltime;

        }

        public void Print()
        {
            Console.WriteLine($"Имя : {_name} Должность : {_post} Зарплата : {_salary} Занятость: {typeofemployment} ");

        }

    }

}
