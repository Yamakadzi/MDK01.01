﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    delegate int Operation(int x);
    class Program
    {
        static void Main(string[] arqs)
        {
            Operation operation = Stepen;
            Console.WriteLine(operation?.Invoke(5));
           
            operation = Modul;
            Console.WriteLine(operation?.Invoke(-5));
           
            operation = Factorial;
            Console.WriteLine(operation?.Invoke(5));


            int Stepen(int x) => x * x;
            int Modul(int x) => Math.Abs(x);
            int Factorial(int x)
            {
                int result = x;
                for (int i = 1; i < x; i++)
                {
                  result *= i;
                }
                return result;
            }
        }
    }
}