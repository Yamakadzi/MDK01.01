﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    internal class Program
    {
        delegate int Operation(int x, int y);
        static void Main(string[] args)
        {

            Operation operation = Summa;
            Console.WriteLine(operation?.Invoke(10,5));

            operation = Raznoct;
            Console.WriteLine(operation?.Invoke(10,5));

            operation = Proizvedenie;
            Console.WriteLine(operation?.Invoke(10,5));

            operation = Chastnoe;
            Console.WriteLine(operation?.Invoke(10,5));

            int Summa(int x, int y) => x + y;
            int Raznoct(int x, int y) => x - y;
            int Proizvedenie(int x, int y) => x * y;
            int Chastnoe(int x, int y) => x / y;
        }
    }
}
