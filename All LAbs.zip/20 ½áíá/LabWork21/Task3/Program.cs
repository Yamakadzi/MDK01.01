﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Task3
{
    delegate int Operation(int x);
    class Program
    {
        private static int Stepen(int x)
        {
            Console.WriteLine(x * x);
            return x;
        }
        private static int Modul(int x)
        {
            Console.WriteLine(Math.Abs(x));
            return x;
        }
        private static int Factorial(int x)
        {
            { int result = x; for (int i = 1; i < x; i++) { result *= i; } return x; Console.WriteLine(result); };
        }
        static void Main(string[] arqs)
        {
            Operation[] operation = new Operation[]
            {
            Stepen, 
            Modul, 
            Factorial
            };
            for (int i = 0; i < operation.Length; i++)
            {
                operation[i]((i));
            }
          
        }
    }
}