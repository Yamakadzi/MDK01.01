﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int r = 5;
            int R = 10;
            double s = Math.PI * Math.Pow(R, 2) - Math.PI * Math.Pow(r, 2);
            double s2 = Math.PI * (R - r) * (R + r);

            Console.WriteLine("Math.PI * Math.Pow(R, 2) - Math.Pi * Math.Pow(r, 2) = " + s);
            Console.WriteLine("Math.PI * (R - r) * (R + r) = " + s2);
            Console.WriteLine("----");

            int n = 5;
            int i, sum = 0;
            for (i = 1; i <= n; i++)
            {
                sum += i;
            }
            Console.WriteLine(sum);

            i = 1;
            sum = (i + n) * n / 2;
            Console.WriteLine(sum);
            Console.WriteLine("----");

            Console.WriteLine(Sum(i, n));

        }
        private static int Sum(int a, int b) => a + b;


    }
}

