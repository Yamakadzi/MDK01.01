﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите название птицы");
           string a = Console.ReadLine();
            List<string> birds = new List<string>() { "Eagle", "Crow", "Raven", a};
            Console.WriteLine($"1) {birds[0]}");
            Console.WriteLine($"2) {birds[1]}");
            Console.WriteLine($"3) {birds[2]}");
            Console.WriteLine($"4) {birds[3]}");
            Console.WriteLine("Всего птиц:");
            Console.WriteLine(birds.Count);
            
            
            Console.WriteLine();


            Console.WriteLine("Введите табельный номер работника :");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите должность работника :");
            string c = Console.ReadLine();
            var Rabotnick = new Dictionary<int, string>()
            {
                { 1098, "Директор"},
                { 3829, "Бухгалтер"},
                { 8013, "Юрист"},
                { b, c } 
            };
            foreach (var person in Rabotnick)
            {
                Console.WriteLine($"key: {person.Key}  value: {person.Value}");
            }
            Console.WriteLine($"Количество работников: {Rabotnick.Count}");
            Console.WriteLine("Введите ключ работника которого вы хотите удалить :");
            int d = int.Parse(Console.ReadLine());
            Rabotnick.Remove(d);
            foreach (var person in Rabotnick)
            {
                Console.WriteLine($"key: {person.Key}  value: {person.Value}");
            }
            Console.WriteLine($"Количество работников: {Rabotnick.Count}");
            Console.WriteLine("Введите табельный номер работника, которого хотите найти:");
            int key = int.Parse(Console.ReadLine());
            
            var rabotnick1 = Rabotnick.ContainsKey(key);
             string value = Console.ReadLine();
            if ( rabotnick1 = Rabotnick.ContainsKey(key))
            {
                Console.WriteLine($" {Rabotnick.ContainsKey(key)} Такой работник есть. Значение: {(key)}  ");

            }
            else
            {
                Console.WriteLine($"Работника с таким табельным номером не существует {rabotnick1}");
            }
            Console.WriteLine($"Количество совпадений значения: {Rabotnick.Values.Count(x => x == value)}");
        }
    }
}
