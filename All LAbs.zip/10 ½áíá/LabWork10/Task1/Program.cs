﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    internal class Program
    {
        static void Main(string[] args)
        {    
            Random random = new Random();
            Rabotnick[] array = new Rabotnick[10];
            for (int i = 0; i < array.Length; i++)
            {
                int salary = random.Next(array.Length);
                array[i] = new Rabotnick("Воронина Анна Андреевна", "бухгалтер", salary);
            }
            Console.WriteLine("До: \n");
            DisplayArray(array);
            Array.Sort(array);
            Console.WriteLine("После: \n");
            DisplayArray(array);
        }
        private static void DisplayArray(Rabotnick[] array)
        {
            foreach (Rabotnick rabotnick in array)
            {
                Console.WriteLine($"Name: {rabotnick.Name}\nPost: {rabotnick.Post}\nSalary: {rabotnick.Salary}\n");
            }
        }
    }
}
