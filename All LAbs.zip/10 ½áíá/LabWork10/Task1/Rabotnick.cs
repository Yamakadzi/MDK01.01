﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    internal sealed class Rabotnick : IComparable
    {
        private string _name;
        private string _post;
        private int _salary;

        internal Rabotnick() : this("Игнатов Степан Андреевич", "уборщик", 20000)
        {
           
        }
        internal Rabotnick(string name, string post, int salary)
        {
            _name = name;
            _post = post;
            _salary = salary;
        }
        internal string Name => _name;
        internal string Post => _post;
        internal int Salary => _salary;
        public int CompareTo(object obj)
        {
            if (obj == null) 
            {
                return 1;
            }
            return (obj as Rabotnick)._salary.CompareTo(_salary);
        }
    }
}
