﻿using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Task1
{
    public partial class Task1 : Form
    {
        public Task1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DirectoryInfo directory = new DirectoryInfo(@"C:\Temp\ispp01");
            FileInfo[] files = directory.GetFiles("*", SearchOption.AllDirectories);

            var result = files
                .Select(gr => new { gr.Name, gr.Extension, gr.DirectoryName, gr.Length, gr.CreationTime, gr.LastWriteTime });
            resultDataGridView.DataSource = result.ToList();

            var numberOfRecords = result.Count();
            numberOfRecordsLabel.Text = "Показано " + numberOfRecords.ToString() + " из " + files.Count() + " записей";
        }

        private void nameTextBox_TextChanged(object sender, EventArgs e)
        {
            DirectoryInfo directory = new DirectoryInfo(@"C:\Temp\ispp01");
            FileInfo[] files = directory.GetFiles("*", SearchOption.AllDirectories);

            var result = files
                .Where(d => d.Name.ToLower().Contains(nameTextBox.Text.ToLower()))
                .Select(gr => new { gr.Name, gr.Extension, gr.DirectoryName, gr.Length, gr.CreationTime, gr.LastWriteTime });
            resultDataGridView.DataSource = result.ToList();
            
            var numberOfRecords = result.Count();
            numberOfRecordsLabel.Text = "Показано " + numberOfRecords.ToString() + " из " + files.Count() + " записей";
        }

        private void resetFilterButton_Click(object sender, EventArgs e)
        {
            nameTextBox.Clear();
        }
    }
}
