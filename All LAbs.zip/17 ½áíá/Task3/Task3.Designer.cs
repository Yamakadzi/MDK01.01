﻿
namespace Task3
{
    partial class Task3
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.resultDataGridView = new System.Windows.Forms.DataGridView();
            this.executableFilesCheckBox = new System.Windows.Forms.CheckBox();
            this.files10KbCheckBox = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.resultDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // resultDataGridView
            // 
            this.resultDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.resultDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.resultDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.resultDataGridView.Location = new System.Drawing.Point(13, 13);
            this.resultDataGridView.Name = "resultDataGridView";
            this.resultDataGridView.RowTemplate.Height = 25;
            this.resultDataGridView.Size = new System.Drawing.Size(604, 230);
            this.resultDataGridView.TabIndex = 0;
            // 
            // executableFilesCheckBox
            // 
            this.executableFilesCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.executableFilesCheckBox.AutoSize = true;
            this.executableFilesCheckBox.Location = new System.Drawing.Point(13, 250);
            this.executableFilesCheckBox.Name = "executableFilesCheckBox";
            this.executableFilesCheckBox.Size = new System.Drawing.Size(146, 19);
            this.executableFilesCheckBox.TabIndex = 1;
            this.executableFilesCheckBox.Text = "Исполняемые файлы";
            this.executableFilesCheckBox.UseVisualStyleBackColor = true;
            this.executableFilesCheckBox.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // files10KbCheckBox
            // 
            this.files10KbCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.files10KbCheckBox.AutoSize = true;
            this.files10KbCheckBox.Location = new System.Drawing.Point(13, 276);
            this.files10KbCheckBox.Name = "files10KbCheckBox";
            this.files10KbCheckBox.Size = new System.Drawing.Size(130, 19);
            this.files10KbCheckBox.TabIndex = 2;
            this.files10KbCheckBox.Text = "Файлы до 10 КБайт";
            this.files10KbCheckBox.UseVisualStyleBackColor = true;
            this.files10KbCheckBox.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // Task3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(629, 374);
            this.Controls.Add(this.files10KbCheckBox);
            this.Controls.Add(this.executableFilesCheckBox);
            this.Controls.Add(this.resultDataGridView);
            this.Name = "Task3";
            this.Text = "Task3";
            this.Load += new System.EventHandler(this.Task3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.resultDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView resultDataGridView;
        private System.Windows.Forms.CheckBox executableFilesCheckBox;
        private System.Windows.Forms.CheckBox files10KbCheckBox;
    }
}

