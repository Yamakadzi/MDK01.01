﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task3
{
    public partial class Task3 : Form
    {
        public Task3()
        {
            InitializeComponent();
        }

        private void Task3_Load(object sender, EventArgs e)
        {
            DirectoryInfo directory = new DirectoryInfo(@"C:\Temp\ispp01");
            FileInfo[] files = directory.GetFiles("*", SearchOption.AllDirectories);

            var result = files
                .Select(gr => new { gr.Name, gr.Extension, gr.DirectoryName, gr.Length, gr.CreationTime, gr.LastWriteTime });
            resultDataGridView.DataSource = result.ToList();
        }
        private void CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            DirectoryInfo directory = new DirectoryInfo(@"C:\Temp\ispp01");
            FileInfo[] files = directory.GetFiles("*", SearchOption.AllDirectories);

            var result = files
                .Select(gr => new { gr.Name, gr.Extension, gr.DirectoryName, gr.Length, gr.CreationTime, gr.LastWriteTime });

            if (files10KbCheckBox.Checked == true)
            {

                result = result.Where(d => d.Length <= 10000);
                
            }

            if (executableFilesCheckBox.Checked == true)
            {
                result = result.Where(d => d.Extension == ".exe");
            }

            resultDataGridView.DataSource = result.ToList();
        }
    }
}
