﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task2
{
    public partial class Task2 : Form
    {
        public Task2()
        {
            InitializeComponent();
        }

        private void Task2_Load(object sender, EventArgs e)
        {
            DirectoryInfo directory = new DirectoryInfo(@"C:\Temp\ispp01");
            FileInfo[] files = directory.GetFiles("*", SearchOption.AllDirectories);

            var result = files
                .Select(gr => new { gr.Name, gr.Extension, gr.DirectoryName, gr.Length, gr.CreationTime, gr.LastWriteTime });
            resultDataGridView.DataSource = result.ToList();
        }

        private void moreOrEqualRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            DirectoryInfo directory = new DirectoryInfo(@"C:\Temp\ispp01");
            FileInfo[] files = directory.GetFiles("*", SearchOption.AllDirectories);

            var result = files
                .Where(d => d.Length >= Int32.Parse(lengthTextBox.Text) )
                .Select(gr => new { gr.Name, gr.Extension, gr.DirectoryName, gr.Length, gr.CreationTime, gr.LastWriteTime });
            resultDataGridView.DataSource = result.ToList();
        }

        private void lessOrEqualRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            DirectoryInfo directory = new DirectoryInfo(@"C:\Temp\ispp01");
            FileInfo[] files = directory.GetFiles("*", SearchOption.AllDirectories);

            var result = files
                .Where(d => d.Length <= Int32.Parse(lengthTextBox.Text))
                .Select(gr => new { gr.Name, gr.Extension, gr.DirectoryName, gr.Length, gr.CreationTime, gr.LastWriteTime });
            resultDataGridView.DataSource = result.ToList();
        }
    }
}
