﻿
namespace Task2
{
    partial class Task2
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.resultDataGridView = new System.Windows.Forms.DataGridView();
            this.lengthTextBox = new System.Windows.Forms.TextBox();
            this.moreOrEqualRadioButton = new System.Windows.Forms.RadioButton();
            this.lessOrEqualRadioButton = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.resultDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // resultDataGridView
            // 
            this.resultDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.resultDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.resultDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.resultDataGridView.Location = new System.Drawing.Point(12, 12);
            this.resultDataGridView.Name = "resultDataGridView";
            this.resultDataGridView.RowTemplate.Height = 25;
            this.resultDataGridView.Size = new System.Drawing.Size(506, 184);
            this.resultDataGridView.TabIndex = 0;
            // 
            // lengthTextBox
            // 
            this.lengthTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lengthTextBox.Location = new System.Drawing.Point(12, 203);
            this.lengthTextBox.Name = "lengthTextBox";
            this.lengthTextBox.PlaceholderText = "Размер файла";
            this.lengthTextBox.Size = new System.Drawing.Size(506, 23);
            this.lengthTextBox.TabIndex = 1;
            // 
            // moreOrEqualRadioButton
            // 
            this.moreOrEqualRadioButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.moreOrEqualRadioButton.AutoSize = true;
            this.moreOrEqualRadioButton.Location = new System.Drawing.Point(12, 231);
            this.moreOrEqualRadioButton.Name = "moreOrEqualRadioButton";
            this.moreOrEqualRadioButton.Size = new System.Drawing.Size(129, 19);
            this.moreOrEqualRadioButton.TabIndex = 2;
            this.moreOrEqualRadioButton.TabStop = true;
            this.moreOrEqualRadioButton.Text = "Больше или равно";
            this.moreOrEqualRadioButton.UseVisualStyleBackColor = true;
            this.moreOrEqualRadioButton.CheckedChanged += new System.EventHandler(this.moreOrEqualRadioButton_CheckedChanged);
            // 
            // lessOrEqualRadioButton
            // 
            this.lessOrEqualRadioButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lessOrEqualRadioButton.AutoSize = true;
            this.lessOrEqualRadioButton.Location = new System.Drawing.Point(12, 257);
            this.lessOrEqualRadioButton.Name = "lessOrEqualRadioButton";
            this.lessOrEqualRadioButton.Size = new System.Drawing.Size(132, 19);
            this.lessOrEqualRadioButton.TabIndex = 3;
            this.lessOrEqualRadioButton.TabStop = true;
            this.lessOrEqualRadioButton.Text = "Меньше или равно";
            this.lessOrEqualRadioButton.UseVisualStyleBackColor = true;
            this.lessOrEqualRadioButton.CheckedChanged += new System.EventHandler(this.lessOrEqualRadioButton_CheckedChanged);
            // 
            // Task2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(530, 364);
            this.Controls.Add(this.lessOrEqualRadioButton);
            this.Controls.Add(this.moreOrEqualRadioButton);
            this.Controls.Add(this.lengthTextBox);
            this.Controls.Add(this.resultDataGridView);
            this.Name = "Task2";
            this.Text = "Task2";
            this.Load += new System.EventHandler(this.Task2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.resultDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView resultDataGridView;
        private System.Windows.Forms.TextBox lengthTextBox;
        private System.Windows.Forms.RadioButton moreOrEqualRadioButton;
        private System.Windows.Forms.RadioButton lessOrEqualRadioButton;
    }
}

