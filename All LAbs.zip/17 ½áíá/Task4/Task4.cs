﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task4
{
    public partial class Task4 : Form
    {
        public Task4()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DirectoryInfo directory = new DirectoryInfo(@"C:\Temp\ispp01");
            FileInfo[] files = directory.GetFiles("*", SearchOption.AllDirectories);

            var result = files
                .Select(gr => new { gr.Name, gr.Extension, gr.DirectoryName, gr.Length, gr.CreationTime, gr.LastWriteTime });
            resultDataGridView.DataSource = result.ToList();
        }

        private void dateCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            DirectoryInfo directory = new DirectoryInfo(@"C:\Temp\ispp01");
            FileInfo[] files = directory.GetFiles("*", SearchOption.AllDirectories);

            var result = files
                .Select(gr => new { gr.Name, gr.Extension, gr.DirectoryName, gr.Length, gr.CreationTime, gr.LastWriteTime });

            if (dateCheckBox.Checked == true)
            {
                result = result.Where(d => d.LastWriteTime.Date == dateTimePicker.Value.Date);
            }

            resultDataGridView.DataSource = result.ToList();
        }
    }
}
