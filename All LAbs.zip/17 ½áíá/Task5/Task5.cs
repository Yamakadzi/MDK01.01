﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task5
{
    public partial class Task5 : Form
    {
        public Task5()
        {
            InitializeComponent();
        }

        private void Task5_Load(object sender, EventArgs e)
        { 
            DirectoryInfo directory = new DirectoryInfo(@"C:\Temp\ispp01");
            FileInfo[] files = directory.GetFiles("*", SearchOption.AllDirectories);

            var result = files
                .Select(gr => new { gr.Name, gr.Extension, gr.DirectoryName, gr.Length, gr.CreationTime, gr.LastWriteTime });
            resultDataGridView.DataSource = result.ToList();
        }

        private void dateComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            DirectoryInfo directory = new DirectoryInfo(@"C:\Temp\ispp01");
            FileInfo[] files = directory.GetFiles("*", SearchOption.AllDirectories);
            
            var result = files
                .Select(gr => new { gr.Name, gr.Extension, gr.DirectoryName, gr.Length, gr.CreationTime, gr.LastWriteTime });

            string selectedState = dateComboBox.SelectedItem.ToString();

            if (selectedState == "Сегодня")
            {
                result = result.Where(d => d.CreationTime.Date == DateTime.Today);
            }
            if (selectedState == "За последнюю неделю")
            {
                result = result.Where(d => d.CreationTime.Date >= DateTime.Now.AddDays(-7));
            }
            if (selectedState == "В этом месяце")
            {
                result = result.Where(d => d.CreationTime.Month == DateTime.Now.Month);
            }
            resultDataGridView.DataSource = result.ToList();

        }
    }
}
