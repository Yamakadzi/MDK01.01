﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> birds = new List<string>() { "Crow", "Eagle", "Raven", "Coco", "Popug", "sgdjlkwsbdljk"  };
            foreach (var bird in birds)
            {
                Console.WriteLine(bird);
            }
            char a;
            
            Console.WriteLine("\nВведите букву с которой  выведутся элементы списка ");
            a = char.Parse(Console.ReadLine());
            for (int i = 0; i < birds.Count; i++)
            {
                if (Char.ToUpper(birds[i][0]) == Char.ToUpper(a)) 
                {
                    Console.WriteLine(birds[i]);
                }
                    
            }

            Console.WriteLine("\nВведите значение который хотите удалить ");
            int b = int.Parse(Console.ReadLine());
            b = b - 1;
            birds.RemoveAt(b);
            foreach (var bird in birds)
            {
               Console.WriteLine(bird);
            }

            Console.WriteLine("\nВведите первое число диапазона с которого выведется список ");
            int c = int.Parse(Console.ReadLine()); 
            Console.WriteLine("\nВведите второе число диапазона");
            int d = int.Parse(Console.ReadLine());
            var resultList = birds.GetRange(c, d);
            var result = resultList.ToArray();
            Console.WriteLine(string.Join(" ", result));

            Console.WriteLine("\nПоследний элемент списка перемещён в начало ");
            string temp = birds[0];
            birds[0] = birds[birds.Count - 1];
            birds[birds.Count - 1] = temp;
            foreach (var bird in birds)
            {
                Console.WriteLine(bird);
            }
            birds.Sort();
            birds.Reverse();
             Console.WriteLine("\nВведите количество элементов которое хотите вывести(элементы будут отсортированы) ");
             d = int.Parse(Console.ReadLine());
            for (int i = 0; i < d; i++)
            { 
                Console.WriteLine(birds[i]);  
            }
            
        }
    }
}
