﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //чёт
         /*   string str = Console.ReadLine();
            int result = str.Replace(" ", "").Length;
            Console.Write("\nКоличество = " + "{0}", str.Length);
            Console.WriteLine("\nКоличество = " + "{0}", result);
            Console.ReadKey();
          */  // нечёт
            string s1 = Console.ReadLine();
            char symbol = char.Parse(Console.ReadLine());
            int indexOfChar = s1.IndexOf(symbol);
            Console.WriteLine(indexOfChar);
        }
    }
}
