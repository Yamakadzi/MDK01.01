﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string slovosochitanie = Console.ReadLine();
            
            Console.WriteLine("Выберите регистр (Верхний, Нижний, Инвертированный)" );
            string register = Console.ReadLine();
            if (register == "Верхний") 
            {
                Console.WriteLine(slovosochitanie.ToUpper());
            }
            if (register == "Нижний")
            {
                Console.WriteLine(slovosochitanie.ToLower());
            }
            if (register == "Инвертированный")
            { 
                string inversedCase = new string(slovosochitanie.Select(c => char.IsLetter(c)
                ? (char.IsUpper(c)
                ? char.ToLower(c)
                : char.ToUpper(c))
                : c).ToArray());
                Console.WriteLine(inversedCase);
            }
            Console.ReadLine();
        }
    }
}
