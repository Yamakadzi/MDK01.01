﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string text1 = Console.ReadLine();
            string text = Console.ReadLine();
            Console.WriteLine(text1 = text1 + "!.?");
            Console.WriteLine(text = text + "!.?");
            Console.ReadKey();
        }
    }
}
