﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Product product = new Product("булкА", 1000.01, DateTime.Now);
            Console.WriteLine(product.ToString());
        }
    }
}
