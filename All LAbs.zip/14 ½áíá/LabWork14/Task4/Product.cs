﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task4
{
    internal class Product
    {
        string name;
        double price;
        DateTime date;
        public Product(string name, double price, DateTime data)
        {
            this.name = name;
            this.price = price; 
            this.date = data;
        
        }
        public override string ToString()
        { 
        return  ($"{new string(new char[] { name[0] }).ToUpper() + new string(name.Substring(1).ToCharArray()).ToLower()};{price:.00};{date.ToString("yyyy-MM-dd")}");
        }
    }
}
